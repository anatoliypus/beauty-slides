import { AppType } from '../model/model';
import constructors from '../constructors/constructors';

const slideWidth = '1000px';
const slideHeight = '800px';

export const presentationReducers = (state: AppType = constructors.createApp(constructors.createSettings(slideWidth, slideHeight)), action: object): AppType => {
    return {
        name: titleReducer(state.name, action),
        currSlideId: currSlideIdReducer(state.currSlideId, action),
        slides: slidesReducer(state.slides, action, state.currSlideId, state.choosedObjectId, state.choosedObjectType),
        settings: state.settings,
        choosedObjectId: choosedObjectIdReducer(state.choosedObjectId, action),
        choosedObjectType
    }
}

// choosedObject = {
//     id: string;
//     type: string
// }
